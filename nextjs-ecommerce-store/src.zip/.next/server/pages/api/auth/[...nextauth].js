"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/[...nextauth]";
exports.ids = ["pages/api/auth/[...nextauth]"];
exports.modules = {

/***/ "@next-auth/mongodb-adapter":
/*!*********************************************!*\
  !*** external "@next-auth/mongodb-adapter" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = require("@next-auth/mongodb-adapter");

/***/ }),

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "next-auth":
/*!****************************!*\
  !*** external "next-auth" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ "next-auth/providers/credentials":
/*!**************************************************!*\
  !*** external "next-auth/providers/credentials" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ "next-auth/providers/facebook":
/*!***********************************************!*\
  !*** external "next-auth/providers/facebook" ***!
  \***********************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/facebook");

/***/ }),

/***/ "next-auth/providers/github":
/*!*********************************************!*\
  !*** external "next-auth/providers/github" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/github");

/***/ }),

/***/ "next-auth/providers/google":
/*!*********************************************!*\
  !*** external "next-auth/providers/google" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/google");

/***/ }),

/***/ "(api)/./src/lib/mongodb.js":
/*!****************************!*\
  !*** ./src/lib/mongodb.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/utils/config */ \"(api)/./src/utils/config.js\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst uri = _utils_config__WEBPACK_IMPORTED_MODULE_0__.DbURL;\nconst options = {\n    useUnifiedTopology: true,\n    useNewUrlParser: true\n};\nlet client;\nlet clientPromise;\nif (!_utils_config__WEBPACK_IMPORTED_MODULE_0__.DbURL) {\n    throw new Error(\"Please add your Mongo URI to .env.local\");\n}\nif (true) {\n    // In development mode, use a global variable so that the value\n    // is preserved across module reloads caused by HMR (Hot Module Replacement).\n    if (!global._mongoClientPromise) {\n        // @ts-ignore\n        client = new mongodb__WEBPACK_IMPORTED_MODULE_1__.MongoClient(uri, options);\n        global._mongoClientPromise = client.connect();\n    }\n    clientPromise = global._mongoClientPromise;\n} else {}\n// Export a module-scoped MongoClient promise. By doing this in a\n// separate module, the client can be shared across functions.\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (clientPromise);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvbGliL21vbmdvZGIuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUF1QztBQUNEO0FBRXRDLE1BQU1FLE1BQU1GLGdEQUFLQTtBQUNqQixNQUFNRyxVQUFVO0lBQ2RDLG9CQUFvQixJQUFJO0lBQ3hCQyxpQkFBaUIsSUFBSTtBQUN2QjtBQUVBLElBQUlDO0FBQ0osSUFBSUM7QUFFSixJQUFJLENBQUNQLGdEQUFLQSxFQUFFO0lBQ1YsTUFBTSxJQUFJUSxNQUFNLDJDQUEyQztBQUM3RCxDQUFDO0FBRUQsSUFBSSxJQUErQixFQUFFO0lBQ25DLCtEQUErRDtJQUMvRCw2RUFBNkU7SUFDN0UsSUFBSSxDQUFDQyxPQUFPQyxtQkFBbUIsRUFBRTtRQUMvQixhQUFhO1FBQ2JKLFNBQVMsSUFBSUwsZ0RBQVdBLENBQUNDLEtBQUtDO1FBQzlCTSxPQUFPQyxtQkFBbUIsR0FBR0osT0FBT0ssT0FBTztJQUM3QyxDQUFDO0lBQ0RKLGdCQUFnQkUsT0FBT0MsbUJBQW1CO0FBQzVDLE9BQU8sRUFLTjtBQUVELGlFQUFpRTtBQUNqRSw4REFBOEQ7QUFDOUQsaUVBQWVILGFBQWFBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0anMtZWNvbW1lcmNlLXN0b3JlLy4vc3JjL2xpYi9tb25nb2RiLmpzPzhiMDMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGJVUkwgfSBmcm9tIFwiQC91dGlscy9jb25maWdcIjtcclxuaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tIFwibW9uZ29kYlwiO1xyXG5cclxuY29uc3QgdXJpID0gRGJVUkw7XHJcbmNvbnN0IG9wdGlvbnMgPSB7XHJcbiAgdXNlVW5pZmllZFRvcG9sb2d5OiB0cnVlLFxyXG4gIHVzZU5ld1VybFBhcnNlcjogdHJ1ZSxcclxufTtcclxuXHJcbmxldCBjbGllbnQ7XHJcbmxldCBjbGllbnRQcm9taXNlO1xyXG5cclxuaWYgKCFEYlVSTCkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcIlBsZWFzZSBhZGQgeW91ciBNb25nbyBVUkkgdG8gLmVudi5sb2NhbFwiKTtcclxufVxyXG5cclxuaWYgKFwiZGV2ZWxvcG1lbnRcIiA9PT0gXCJkZXZlbG9wbWVudFwiKSB7XHJcbiAgLy8gSW4gZGV2ZWxvcG1lbnQgbW9kZSwgdXNlIGEgZ2xvYmFsIHZhcmlhYmxlIHNvIHRoYXQgdGhlIHZhbHVlXHJcbiAgLy8gaXMgcHJlc2VydmVkIGFjcm9zcyBtb2R1bGUgcmVsb2FkcyBjYXVzZWQgYnkgSE1SIChIb3QgTW9kdWxlIFJlcGxhY2VtZW50KS5cclxuICBpZiAoIWdsb2JhbC5fbW9uZ29DbGllbnRQcm9taXNlKSB7XHJcbiAgICAvLyBAdHMtaWdub3JlXHJcbiAgICBjbGllbnQgPSBuZXcgTW9uZ29DbGllbnQodXJpLCBvcHRpb25zKTtcclxuICAgIGdsb2JhbC5fbW9uZ29DbGllbnRQcm9taXNlID0gY2xpZW50LmNvbm5lY3QoKTtcclxuICB9XHJcbiAgY2xpZW50UHJvbWlzZSA9IGdsb2JhbC5fbW9uZ29DbGllbnRQcm9taXNlO1xyXG59IGVsc2Uge1xyXG4gIC8vIEluIHByb2R1Y3Rpb24gbW9kZSwgaXQncyBiZXN0IHRvIG5vdCB1c2UgYSBnbG9iYWwgdmFyaWFibGUuXHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIGNsaWVudCA9IG5ldyBNb25nb0NsaWVudCh1cmksIG9wdGlvbnMpO1xyXG4gIGNsaWVudFByb21pc2UgPSBjbGllbnQuY29ubmVjdCgpO1xyXG59XHJcblxyXG4vLyBFeHBvcnQgYSBtb2R1bGUtc2NvcGVkIE1vbmdvQ2xpZW50IHByb21pc2UuIEJ5IGRvaW5nIHRoaXMgaW4gYVxyXG4vLyBzZXBhcmF0ZSBtb2R1bGUsIHRoZSBjbGllbnQgY2FuIGJlIHNoYXJlZCBhY3Jvc3MgZnVuY3Rpb25zLlxyXG5leHBvcnQgZGVmYXVsdCBjbGllbnRQcm9taXNlO1xyXG4iXSwibmFtZXMiOlsiRGJVUkwiLCJNb25nb0NsaWVudCIsInVyaSIsIm9wdGlvbnMiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJ1c2VOZXdVcmxQYXJzZXIiLCJjbGllbnQiLCJjbGllbnRQcm9taXNlIiwiRXJyb3IiLCJnbG9iYWwiLCJfbW9uZ29DbGllbnRQcm9taXNlIiwiY29ubmVjdCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./src/lib/mongodb.js\n");

/***/ }),

/***/ "(api)/./src/pages/api/auth/[...nextauth].js":
/*!*********************************************!*\
  !*** ./src/pages/api/auth/[...nextauth].js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"authOptions\": () => (/* binding */ authOptions),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"next-auth\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/github */ \"next-auth/providers/github\");\n/* harmony import */ var next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_auth_providers_google__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-auth/providers/google */ \"next-auth/providers/google\");\n/* harmony import */ var next_auth_providers_google__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_google__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_auth_providers_facebook__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-auth/providers/facebook */ \"next-auth/providers/facebook\");\n/* harmony import */ var next_auth_providers_facebook__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_facebook__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next-auth/providers/credentials */ \"next-auth/providers/credentials\");\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _utils_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/utils/config */ \"(api)/./src/utils/config.js\");\n/* harmony import */ var _next_auth_mongodb_adapter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @next-auth/mongodb-adapter */ \"@next-auth/mongodb-adapter\");\n/* harmony import */ var _next_auth_mongodb_adapter__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_next_auth_mongodb_adapter__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var _lib_mongodb__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @/lib/mongodb */ \"(api)/./src/lib/mongodb.js\");\n\n\n\n\n\n\n\n\nconst authOptions = {\n    // Configure one or more authentication providers\n    pages: {\n        signIn: \"/auth/signin\"\n    },\n    providers: [\n        next_auth_providers_github__WEBPACK_IMPORTED_MODULE_1___default()({\n            clientId: _utils_config__WEBPACK_IMPORTED_MODULE_5__.GITHUB_ID,\n            clientSecret: _utils_config__WEBPACK_IMPORTED_MODULE_5__.GITHUB_SECRET\n        }),\n        next_auth_providers_google__WEBPACK_IMPORTED_MODULE_2___default()({\n            clientId: _utils_config__WEBPACK_IMPORTED_MODULE_5__.GOOGLE_CLIENT_ID,\n            clientSecret: _utils_config__WEBPACK_IMPORTED_MODULE_5__.GOOGLE_CLIENT_SECRET\n        }),\n        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_4___default()({\n            name: \"Email and Password\",\n            credentials: {\n                email: {\n                    label: \"Email\",\n                    type: \"text\"\n                },\n                password: {\n                    label: \"Password\",\n                    type: \"password\"\n                }\n            },\n            authorize: async (credentials)=>{\n                const payload = {\n                    email: credentials.email,\n                    password: credentials.password\n                };\n                const url = `http://localhost:3000/api/auth/login`;\n                const res = await fetch(url, {\n                    method: \"POST\",\n                    body: JSON.stringify(payload),\n                    headers: {\n                        \"Content-Type\": \"application/json\"\n                    }\n                });\n                const user = await res.json();\n                if (res.ok && user) {\n                    return user;\n                }\n                return null;\n            }\n        })\n    ],\n    adapter: (0,_next_auth_mongodb_adapter__WEBPACK_IMPORTED_MODULE_6__.MongoDBAdapter)(_lib_mongodb__WEBPACK_IMPORTED_MODULE_7__[\"default\"], {\n        databaseName: \"authDatabase\"\n    }),\n    database: _utils_config__WEBPACK_IMPORTED_MODULE_5__.DbURL,\n    session: {\n        jwt: true\n    },\n    jwt: {\n        secret: \"asdjhasdef\"\n    }\n};\n// @ts-ignore\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvcGFnZXMvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQWlDO0FBQ3VCO0FBQ0E7QUFDSTtBQUNLO0FBT3pDO0FBQ29DO0FBQ2xCO0FBRW5DLE1BQU1ZLGNBQWM7SUFDekIsaURBQWlEO0lBQ2pEQyxPQUFPO1FBQ0xDLFFBQVE7SUFFVjtJQUNBQyxXQUFXO1FBQ1RkLGlFQUFjQSxDQUFDO1lBQ2JlLFVBQVVWLG9EQUFTQTtZQUNuQlcsY0FBY1Ysd0RBQWFBO1FBQzdCO1FBRUFMLGlFQUFjQSxDQUFDO1lBQ2JjLFVBQVVSLDJEQUFnQkE7WUFDMUJTLGNBQWNSLCtEQUFvQkE7UUFDcEM7UUFDQUwsc0VBQW1CQSxDQUFDO1lBQ2xCYyxNQUFNO1lBQ05DLGFBQWE7Z0JBQ1hDLE9BQU87b0JBQUVDLE9BQU87b0JBQVNDLE1BQU07Z0JBQU07Z0JBQ3JDQyxVQUFVO29CQUFFRixPQUFPO29CQUFZQyxNQUFNO2dCQUFXO1lBQ2xEO1lBQ0FFLFdBQVcsT0FBT0wsY0FBZ0I7Z0JBRTlCLE1BQU1NLFVBQVU7b0JBQ2RMLE9BQU9ELFlBQVlDLEtBQUs7b0JBQ3hCRyxVQUFVSixZQUFZSSxRQUFRO2dCQUNoQztnQkFFQSxNQUFNRyxNQUFNLENBQUMsb0NBQW9DLENBQUM7Z0JBRWxELE1BQU1DLE1BQU0sTUFBTUMsTUFBTUYsS0FBSztvQkFDM0JHLFFBQVE7b0JBQ1JDLE1BQU1DLEtBQUtDLFNBQVMsQ0FBQ1A7b0JBQ3JCUSxTQUFTO3dCQUFFLGdCQUFnQjtvQkFBbUI7Z0JBQ2hEO2dCQUVBLE1BQU1DLE9BQU8sTUFBTVAsSUFBSVEsSUFBSTtnQkFHM0IsSUFBSVIsSUFBSVMsRUFBRSxJQUFJRixNQUFNO29CQUNsQixPQUFPQTtnQkFDVCxDQUFDO2dCQUdELE9BQU8sSUFBSTtZQUVmO1FBQ0Y7S0FLRDtJQUNERyxTQUFTM0IsMEVBQWNBLENBQUNDLG9EQUFhQSxFQUFFO1FBQ3JDMkIsY0FBYztJQUNoQjtJQUNBQyxVQUFVbEMsZ0RBQUtBO0lBQ2ZtQyxTQUFTO1FBQ1BDLEtBQUssSUFBSTtJQUNYO0lBQ0FBLEtBQUs7UUFDSEMsUUFBUTtJQUNWO0FBQ0YsRUFBRTtBQUVGLGFBQWE7QUFDYixpRUFBZTFDLGdEQUFRQSxDQUFDWSxZQUFZQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dGpzLWVjb21tZXJjZS1zdG9yZS8uL3NyYy9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLmpzPzc4YWIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IE5leHRBdXRoIGZyb20gXCJuZXh0LWF1dGhcIjtcclxuaW1wb3J0IEdpdGh1YlByb3ZpZGVyIGZyb20gXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2dpdGh1YlwiO1xyXG5pbXBvcnQgR29vZ2xlUHJvdmlkZXIgZnJvbSBcIm5leHQtYXV0aC9wcm92aWRlcnMvZ29vZ2xlXCI7XHJcbmltcG9ydCBGYWNlYm9va1Byb3ZpZGVyIGZyb20gXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2ZhY2Vib29rXCI7XHJcbmltcG9ydCBDcmVkZW50aWFsc1Byb3ZpZGVyIGZyb20gXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2NyZWRlbnRpYWxzXCJcclxuaW1wb3J0IHtcclxuICBEYlVSTCxcclxuICBHSVRIVUJfSUQsXHJcbiAgR0lUSFVCX1NFQ1JFVCxcclxuICBHT09HTEVfQ0xJRU5UX0lELFxyXG4gIEdPT0dMRV9DTElFTlRfU0VDUkVULFxyXG59IGZyb20gXCJAL3V0aWxzL2NvbmZpZ1wiO1xyXG5pbXBvcnQgeyBNb25nb0RCQWRhcHRlciB9IGZyb20gXCJAbmV4dC1hdXRoL21vbmdvZGItYWRhcHRlclwiO1xyXG5pbXBvcnQgY2xpZW50UHJvbWlzZSBmcm9tIFwiQC9saWIvbW9uZ29kYlwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IGF1dGhPcHRpb25zID0ge1xyXG4gIC8vIENvbmZpZ3VyZSBvbmUgb3IgbW9yZSBhdXRoZW50aWNhdGlvbiBwcm92aWRlcnNcclxuICBwYWdlczoge1xyXG4gICAgc2lnbkluOiAnL2F1dGgvc2lnbmluJyxcclxuICBcclxuICB9LFxyXG4gIHByb3ZpZGVyczogW1xyXG4gICAgR2l0aHViUHJvdmlkZXIoe1xyXG4gICAgICBjbGllbnRJZDogR0lUSFVCX0lELFxyXG4gICAgICBjbGllbnRTZWNyZXQ6IEdJVEhVQl9TRUNSRVQsXHJcbiAgICB9KSxcclxuXHJcbiAgICBHb29nbGVQcm92aWRlcih7XHJcbiAgICAgIGNsaWVudElkOiBHT09HTEVfQ0xJRU5UX0lELFxyXG4gICAgICBjbGllbnRTZWNyZXQ6IEdPT0dMRV9DTElFTlRfU0VDUkVULFxyXG4gICAgfSksXHJcbiAgICBDcmVkZW50aWFsc1Byb3ZpZGVyKHsgICAgICBcclxuICAgICAgbmFtZTogJ0VtYWlsIGFuZCBQYXNzd29yZCcsXHJcbiAgICAgIGNyZWRlbnRpYWxzOiB7XHJcbiAgICAgICAgZW1haWw6IHsgbGFiZWw6ICdFbWFpbCcsIHR5cGU6ICd0ZXh0J30sXHJcbiAgICAgICAgcGFzc3dvcmQ6IHsgbGFiZWw6ICdQYXNzd29yZCcsIHR5cGU6ICdwYXNzd29yZCcgfVxyXG4gICAgICB9LFxyXG4gICAgICBhdXRob3JpemU6IGFzeW5jIChjcmVkZW50aWFscykgPT4ge1xyXG4gICBcclxuICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAgIGVtYWlsOiBjcmVkZW50aWFscy5lbWFpbCxcclxuICAgICAgICAgICAgcGFzc3dvcmQ6IGNyZWRlbnRpYWxzLnBhc3N3b3JkLFxyXG4gICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICBjb25zdCB1cmwgPSBgaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9hdXRoL2xvZ2luYFxyXG4gICAgICAgICAgICAgXHJcbiAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcclxuICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBheWxvYWQpLFxyXG4gICAgICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH1cclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICBcclxuICAgICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCByZXMuanNvbigpXHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBpZiAocmVzLm9rICYmIHVzZXIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHVzZXI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgXHJcbiAgICAgIH1cclxuICAgIH0pLFxyXG4gICAgLy8gRmFjZWJvb2tQcm92aWRlcih7XHJcbiAgICAvLyAgIGNsaWVudElkOiBwcm9jZXNzLmVudi5GQUNFQk9PS19DTElFTlRfSUQsXHJcbiAgICAvLyAgIGNsaWVudFNlY3JldDogcHJvY2Vzcy5lbnYuRkFDRUJPT0tfQ0xJRU5UX1NFQ1JFVFxyXG4gICAgLy8gfSlcclxuICBdLFxyXG4gIGFkYXB0ZXI6IE1vbmdvREJBZGFwdGVyKGNsaWVudFByb21pc2UsIHtcclxuICAgIGRhdGFiYXNlTmFtZTogXCJhdXRoRGF0YWJhc2VcIixcclxuICB9KSxcclxuICBkYXRhYmFzZTogRGJVUkwsXHJcbiAgc2Vzc2lvbjoge1xyXG4gICAgand0OiB0cnVlLFxyXG4gIH0sXHJcbiAgand0OiB7XHJcbiAgICBzZWNyZXQ6IFwiYXNkamhhc2RlZlwiLFxyXG4gIH0sXHJcbn07XHJcblxyXG4vLyBAdHMtaWdub3JlXHJcbmV4cG9ydCBkZWZhdWx0IE5leHRBdXRoKGF1dGhPcHRpb25zKTtcclxuIl0sIm5hbWVzIjpbIk5leHRBdXRoIiwiR2l0aHViUHJvdmlkZXIiLCJHb29nbGVQcm92aWRlciIsIkZhY2Vib29rUHJvdmlkZXIiLCJDcmVkZW50aWFsc1Byb3ZpZGVyIiwiRGJVUkwiLCJHSVRIVUJfSUQiLCJHSVRIVUJfU0VDUkVUIiwiR09PR0xFX0NMSUVOVF9JRCIsIkdPT0dMRV9DTElFTlRfU0VDUkVUIiwiTW9uZ29EQkFkYXB0ZXIiLCJjbGllbnRQcm9taXNlIiwiYXV0aE9wdGlvbnMiLCJwYWdlcyIsInNpZ25JbiIsInByb3ZpZGVycyIsImNsaWVudElkIiwiY2xpZW50U2VjcmV0IiwibmFtZSIsImNyZWRlbnRpYWxzIiwiZW1haWwiLCJsYWJlbCIsInR5cGUiLCJwYXNzd29yZCIsImF1dGhvcml6ZSIsInBheWxvYWQiLCJ1cmwiLCJyZXMiLCJmZXRjaCIsIm1ldGhvZCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwiaGVhZGVycyIsInVzZXIiLCJqc29uIiwib2siLCJhZGFwdGVyIiwiZGF0YWJhc2VOYW1lIiwiZGF0YWJhc2UiLCJzZXNzaW9uIiwiand0Iiwic2VjcmV0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./src/pages/api/auth/[...nextauth].js\n");

/***/ }),

/***/ "(api)/./src/utils/config.js":
/*!*****************************!*\
  !*** ./src/utils/config.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"DBpass\": () => (/* binding */ DBpass),\n/* harmony export */   \"DBusername\": () => (/* binding */ DBusername),\n/* harmony export */   \"DbURL\": () => (/* binding */ DbURL),\n/* harmony export */   \"FACEBOOK_CLIENT_ID\": () => (/* binding */ FACEBOOK_CLIENT_ID),\n/* harmony export */   \"FACEBOOK_CLIENT_SECRET\": () => (/* binding */ FACEBOOK_CLIENT_SECRET),\n/* harmony export */   \"GITHUB_ID\": () => (/* binding */ GITHUB_ID),\n/* harmony export */   \"GITHUB_SECRET\": () => (/* binding */ GITHUB_SECRET),\n/* harmony export */   \"GOOGLE_CLIENT_ID\": () => (/* binding */ GOOGLE_CLIENT_ID),\n/* harmony export */   \"GOOGLE_CLIENT_SECRET\": () => (/* binding */ GOOGLE_CLIENT_SECRET),\n/* harmony export */   \"apiUrl\": () => (/* binding */ apiUrl),\n/* harmony export */   \"appBaseUrl\": () => (/* binding */ appBaseUrl),\n/* harmony export */   \"dataBaseUrl\": () => (/* binding */ dataBaseUrl)\n/* harmony export */ });\nconst GITHUB_ID = \"77848302a7f8f5720040\";\nconst GITHUB_SECRET = \"1969e296a2dae89668088525dda82663075dd858\";\nconst GOOGLE_CLIENT_ID = \"234636235499-tkpj3bio2tnmlvk0iv19p03g3lmhlitt.apps.googleusercontent.com\";\nconst GOOGLE_CLIENT_SECRET = \"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\";\nconst FACEBOOK_CLIENT_ID = \"\";\nconst FACEBOOK_CLIENT_SECRET = \"\";\nconst appBaseUrl = \"http://localhost:3000\";\nconst DBpass = \"user123Pass\";\nconst DBusername = \"kishor81160\";\nconst DbURL = `mongodb+srv://${DBusername}:${DBpass}@cluster0.884ticn.mongodb.net/userdata?retryWrites=true&w=majority`;\nconst apiUrl = \"http://localhost:1337\";\nconst dataBaseUrl = \"postgres://strapi:strapi@localhost:5432/strapi?synchronize=true\";\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvdXRpbHMvY29uZmlnLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFPLE1BQU1BLFlBQVksdUJBQXVCO0FBQ3pDLE1BQU1DLGdCQUFnQiwyQ0FBMkM7QUFDakUsTUFBTUMsbUJBQ1gsMkVBQTJFO0FBQ3RFLE1BQU1DLHVCQUF1QixzQ0FBc0M7QUFDbkUsTUFBTUMscUJBQXFCLEdBQUc7QUFDOUIsTUFBTUMseUJBQXlCLEdBQUc7QUFDbEMsTUFBTUMsYUFBYSx3QkFBd0I7QUFDM0MsTUFBTUMsU0FBUyxjQUFjO0FBQzdCLE1BQU1DLGFBQWEsY0FBYztBQUNqQyxNQUFNQyxRQUFRLENBQUMsY0FBYyxFQUFFRCxXQUFXLENBQUMsRUFBRUQsT0FBTyxrRUFBa0UsQ0FBQyxDQUFDO0FBQ3hILE1BQU1HLFNBQU8sd0JBQXVCO0FBQ3BDLE1BQU1DLGNBQVksa0VBQWlFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmV4dGpzLWVjb21tZXJjZS1zdG9yZS8uL3NyYy91dGlscy9jb25maWcuanM/MDc4MSJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgR0lUSFVCX0lEID0gXCI3Nzg0ODMwMmE3ZjhmNTcyMDA0MFwiO1xyXG5leHBvcnQgY29uc3QgR0lUSFVCX1NFQ1JFVCA9IFwiMTk2OWUyOTZhMmRhZTg5NjY4MDg4NTI1ZGRhODI2NjMwNzVkZDg1OFwiO1xyXG5leHBvcnQgY29uc3QgR09PR0xFX0NMSUVOVF9JRCA9XHJcbiAgXCIyMzQ2MzYyMzU0OTktdGtwajNiaW8ydG5tbHZrMGl2MTlwMDNnM2xtaGxpdHQuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb21cIjtcclxuZXhwb3J0IGNvbnN0IEdPT0dMRV9DTElFTlRfU0VDUkVUID0gXCJHT0NTUFgteGlvRjhydkJRdHZ2T3RMQzhOa3pRMkpuV25IOVwiO1xyXG5leHBvcnQgY29uc3QgRkFDRUJPT0tfQ0xJRU5UX0lEID0gXCJcIjtcclxuZXhwb3J0IGNvbnN0IEZBQ0VCT09LX0NMSUVOVF9TRUNSRVQgPSBcIlwiO1xyXG5leHBvcnQgY29uc3QgYXBwQmFzZVVybCA9IFwiaHR0cDovL2xvY2FsaG9zdDozMDAwXCI7XHJcbmV4cG9ydCBjb25zdCBEQnBhc3MgPSBcInVzZXIxMjNQYXNzXCI7XHJcbmV4cG9ydCBjb25zdCBEQnVzZXJuYW1lID0gXCJraXNob3I4MTE2MFwiO1xyXG5leHBvcnQgY29uc3QgRGJVUkwgPSBgbW9uZ29kYitzcnY6Ly8ke0RCdXNlcm5hbWV9OiR7REJwYXNzfUBjbHVzdGVyMC44ODR0aWNuLm1vbmdvZGIubmV0L3VzZXJkYXRhP3JldHJ5V3JpdGVzPXRydWUmdz1tYWpvcml0eWA7XHJcbmV4cG9ydCBjb25zdCBhcGlVcmw9J2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNydcclxuZXhwb3J0IGNvbnN0IGRhdGFCYXNlVXJsPSdwb3N0Z3JlczovL3N0cmFwaTpzdHJhcGlAbG9jYWxob3N0OjU0MzIvc3RyYXBpP3N5bmNocm9uaXplPXRydWUnIl0sIm5hbWVzIjpbIkdJVEhVQl9JRCIsIkdJVEhVQl9TRUNSRVQiLCJHT09HTEVfQ0xJRU5UX0lEIiwiR09PR0xFX0NMSUVOVF9TRUNSRVQiLCJGQUNFQk9PS19DTElFTlRfSUQiLCJGQUNFQk9PS19DTElFTlRfU0VDUkVUIiwiYXBwQmFzZVVybCIsIkRCcGFzcyIsIkRCdXNlcm5hbWUiLCJEYlVSTCIsImFwaVVybCIsImRhdGFCYXNlVXJsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./src/utils/config.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./src/pages/api/auth/[...nextauth].js"));
module.exports = __webpack_exports__;

})();